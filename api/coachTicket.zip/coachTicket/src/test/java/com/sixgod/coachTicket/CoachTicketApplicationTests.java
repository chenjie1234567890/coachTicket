package com.sixgod.coachTicket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoachTicketApplicationTests {

	@Test
	void contextLoads() {
	}

}
